"""
The main program should use functions from music_reports and display modules
"""
import file_handling
import display
import music_reports

def get_input(required):
    inputs = []
    while len(inputs) < required:
        inputs.append(input("Please enter parameters: "))
    return inputs


def delete_album_by_artist_and_album_name(albums, artist, album_name):
    """
    Deletes album of given name by given artist from list and updates data file

    :param list albums: currently existing albums
    :param str artist: artist who recorded the album
    :param str album_name: name of album to be deleted

    :returns: updated albums' list
    :rtype: list
    """
    new_table = []

    for i in range(len(albums)):
        if (albums[i][0] != artist) and (albums[i][1] != album_name):
            new_table.append(albums[i])
    albums = new_table
    file_handling.export_data(albums, filename='albums_data.txt', mode='w')
    return albums

def menu(albums):
    menu_commands = ["Print albums", "Export albums", "Delete album", "List genre", "Genre stats", "Longest album", "Oldest album", "Oldest by genre", "Total length"]
    display.print_program_menu(menu_commands)
    choice = int((get_input(1))[0])
    if choice == 0:
        display.print_albums_list(albums)
    elif choice == 1:
        choice = (get_input(1))[0]
        if choice == "a":
            file_handling.export_data(albums, filename='albums_data.txt', mode='a')
        elif choice == "w":
            file_handling.export_data(albums, filename='albums_data.txt', mode='w')
        else:
            raise ValueError("Input should be 'a' or 'w'!")
    elif choice == 2:
        choice = get_input(2)
        artist = choice[0]
        album_name = choice[1]
        delete_album_by_artist_and_album_name(albums, artist, album_name)
    elif choice == 3:
        genre = (get_input(1)[0])
        display.print_command_result(str(music_reports.get_albums_by_genre(albums, genre)))
    elif choice == 4:
        display.print_command_result(str(music_reports.get_genre_stats(albums)))
    elif choice == 5:
        display.print_command_result(str(music_reports.get_longest_album(albums)))
    elif choice == 6:
        display.print_command_result(str(music_reports.get_last_oldest(albums)))
    elif choice == 7:
        genre = (get_input(1)[0])
        display.print_command_result(str(music_reports.get_last_oldest_of_genre(albums, genre)))
    elif choice == 8:
        display.print_command_result(str(music_reports.get_total_albums_length(albums)))
    else:
        print("\nSorry, no such menu choice.\n")
        menu(albums)
        

def main():
    """
    Calls all interaction between user and program, handles program menu
    and user inputs. It should repeat displaying menu and asking for
    input until that moment.

    You should create new functions and call them from main whenever it can
    make the code cleaner
    """
    albums = file_handling.import_data(filename='albums_data.txt')
    menu(albums)
    

if __name__ == '__main__':
    main()
