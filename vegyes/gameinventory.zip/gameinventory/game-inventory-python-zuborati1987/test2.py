from random import randint


y = randint(1, 15)
z = 1
list1 = []
list2 = []
while z < y:
        x = randint(1, 100)
        list1.append(x)
        z += 1
y = randint(1, 15)
z = 1
while z < y:
        x = randint(1, 100)
        list2.append(x)
        z += 1  
