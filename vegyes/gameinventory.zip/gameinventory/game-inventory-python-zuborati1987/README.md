# python_game_inventory

This you your assignment, for details see the related page in the curriculum and gameInventory.py.
You will only need to edit gameInventory.py! (and can create new files, for example sample .csv data)
