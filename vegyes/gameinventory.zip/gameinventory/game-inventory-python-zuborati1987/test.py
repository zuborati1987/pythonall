# This is the file where you must work. Write code in the functions, create new functions, 
# so they work according to the specification

inv = {'rope': 1, 'torch': 6, 'gold coin': 42, 'dagger': 1, 'arrow': 12}
added_items = ['gold coin', 'dagger', 'gold coin', 'gold coin', 'ruby']
filename = "import_inventory.csv"

# Displays the inventory.
def display_inventory(inv):
    print("Inventory:")
    for k, v in inv.items():
        print(v, k)
    total = sum(inv.values())
    print("Total number of items: ", total)


# Adds to the inventory dictionary a list of items from added_items.
def add_to_inventory(inv, added_items):      
    to_add = {}
    b = inv 
    for items in added_items: 
        to_add[items] = added_items.count(items)
        a = to_add
    for k in b:  # for key in added_items
        if k in a: # if key is in inv
            b[k] = b[k] + a[k] # added_items key = added_items key + inv key
    c = {**a, **b}
    inv.update(c)
    return inv


# Takes your inventory and displays it in a well-organized table with 
# each column right-justified. The input argument is an order parameter (string)
# which works as the following:
# - None (by default) means the table is unordered
# - "count,desc" means the table is ordered by count (of items in the inventory) 
#   in descending order
# - "count,asc" means the table is ordered by count in ascending order
def print_table(inv, order=None):
    order = input("Order? ")
    count = 0
    for i in inv:
        if len(i) > count:
            count = len(i)
            x = len(i)
    print("Inventory:")
    print("Count".rjust(10), "Item name".rjust(x+10))
    print(("-") * (x+21))
    if order == "count, asc":
        for k, v in sorted(inv.items(), key=lambda x: x[1]):
            a = str(k)
            b = str(v)
            print(b.rjust(10), a.rjust(x+10))
    elif order == "count, desc":
        for k, v in sorted(inv.items(),reverse=True, key=lambda x: x[1]):
            a = str(k)
            b = str(v)
            print(b.rjust(10), a.rjust(x+10))
    else:
        order == "None"
        for k, v in inv.items():
            a = str(k)
            b = str(v)
            print(b.rjust(10), a.rjust(x+10))
    total = sum(inv.values())
    c = str(total)
    print(("-") * (x+21))
    print("Total number of items: ", c.rjust(x-3))


# Imports new inventory items from a file
# The filename comes as an argument, but by default it's 
# "import_inventory.csv". The import automatically merges items by name.
# The file format is plain text with comma separated values (CSV).
def import_inventory(added_items, inv, filename="import_inventory.csv"):
    with open(filename, "r") as f:
        added_items[:] = list(f.read().split(","))      
    return added_items


# Exports the inventory into a .csv file.
# if the filename argument is None it creates and overwrites a file
# called "export_inventory.csv". The file format is the same plain text 
# with comma separated values (CSV).
def export_inventory(inv, filename="export_inventory.csv"):
    with open(filename, 'w') as f:
        for key, val in inv.items():
            f.write((key + ", ") * val)

def main():
    add_to_inventory(inv, added_items)
    display_inventory(inv)
    print_table(inv)
    import_inventory(added_items, inv, filename)
    add_to_inventory(inv, added_items)
    display_inventory(inv)
    export_inventory(inv, filename="export_inventory.csv")

if __name__ == '__main__':
    main()